const config = {
  apiUrl: 'http://localhost:5225'
};

export default config;