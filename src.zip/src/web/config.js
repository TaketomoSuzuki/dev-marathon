const config = {
  apiUrl: '/api_taketomo_suzuki'
};

export default config;